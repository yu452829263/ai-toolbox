---
name: dida-cli
description: "用 dida CLI 管理滴答清单（滴答/Dida365/TickTick）的任务与清单：查待办、建任务（没说时间就先问是定时/普通/闲时）、改任务、标完成、删任务、按清单与优先级与标签与日期筛选、任务评论。触发场景：用户说「待办 / 我的待办 / 今天要做什么 / 这周任务 / 加个任务 / 记一下 / 建个待办 / 提醒我 / 任务清单 / 收件箱 / 标记完成 / 做完了 / 滴答 / 滴答清单 / dida / TickTick」。读操作直接执行；单条写操作直接执行，批量写先回显清单再动手。（孵化中 v0.2.0-alpha）"
license: MIT
compatibility: 需要已安装 @suibiji/dida-cli 并完成 dida auth login
allowed-tools: Bash(dida *), Bash(jq *), Bash(python3 *), Bash(date *), Bash(grep *)
argument-hint: "[自然语言的待办请求]"
---

# dida-cli（孵化中 v0.2.0-alpha）

在终端管理滴答清单的任务与清单。封装 [DIDA Open API v1](https://developer.dida365.com/docs#/openapi)，所有命令 <1s，凭据在 `~/.config/dida-cli/config.json`（600，仅 `access_token`）。

> Last updated: 2026-09-19

**当前形态**：九个边界全部实测坐实并配了闭坑动作，写链路（create→update→complete→delete→move）逐条回读验证过，三个封装函数喂坏输入确认会 fail。但**真实使用场景只跑过一轮**（整理收件箱 + 补测写操作），意图映射表是否覆盖日常说法、批量场景下的表现、长期使用后 token 失效的处理，都还没有实战数据。`--reminders` / `comment delete` / `project group|column` 未测，`habit` / `focus` / `countdown` 未纳入。后续打磨方向见 §验证状态。

## 日期处理

用户说「明天 / 这周 / 下周五」时，**先跑一次 `date` 拿真实日期**，不要从上下文猜（skill 文本里的 `!`cmd`` 动态语法在本环境不展开，别指望它）：

```bash
date +"今天 %Y-%m-%d %A %H:%M %Z"; date -v+1d +"明天 %Y-%m-%d"; date -v+1d -v+sun +"本周日 %Y-%m-%d"
```

拿到日期后再拼成坑 2 要求的完整格式。

## 前置检查

动手前先确认已登录，未登录时**不要自己跑 `dida auth login`**（它会开浏览器并阻塞），让用户在对话框输入 `! dida auth login`：

```bash
dida auth status    # → "✓ 已登录" 才继续
```

## 作用域

**做**：任务的增删改查与完成、清单与标签读取、任务评论。
**不做**：不碰 `habit` / `focus` / `countdown`（本 skill 未验证）；不删清单（`project delete`）；不替用户批量清理历史任务。
**边界**：用户对本 skill 的要求只到任务的写入、读取、修改。用户把滴答当「数据库 + 待办管理」用，但不要主动提议 schema 约定、批量读写框架、归档查询层这类数据库化扩展。

## 意图 → 命令

先拿 projectId（建任务必需），再操作：

| 用户意图 | 命令 |
| --- | --- |
| 「我有哪些待办」「最近要做什么」 | `dida task filter --status 0` ← **跨全部清单，不带 `--projects`** |
| 「列一下清单 / 有哪些清单」 | `dida project list` |
| 「X 清单里有什么」 | `dida task filter --projects <projectId> --status 0` |
| 「X 清单完整内容（含看板列）」 | `dida project data <projectId> --json` |
| 「加个任务 / 记一下 / 提醒我」 | 先分流（见 §两类待办），再 `dida task create --title "..." --project <projectId>` |
| 「加个高优先级的 / 带截止时间的」 | `dida task create --title "..." --project <id> --priority 5 --due-date "2026-09-20T18:00:00+0800"` |
| 「加个带子任务的」 | `dida task create --title "..." --project <id> --items "步骤1,步骤2,步骤3" --desc "描述"` ← 描述用 `--desc`（坑 9） |
| 「改标题 / 改优先级 / 改时间」 | `dida task update <taskId> --id <taskId> --project <projectId> --title "..."` ← **id 写两遍** |
| 「做完了 / 标记完成」 | `dida task complete <projectId> <taskId>` |
| 「删掉这条」 | `dida task delete <projectId> <taskId>` |
| 「挪到另一个清单」 | `dida task move --from <srcId> --to <dstId> --task <taskId>` |
| 「高优先级的有哪些」 | `dida task filter --priority 3,5 --status 0` |
| 「带 X 标签的」 | `dida task filter --tag X --status 0` |
| 「这周完成了什么」 | `dida task completed --start-date "2026-09-14T00:00:00+0800" --end-date "2026-09-20T23:59:59+0800"` |
| 「看这条任务详情」 | `dida task get <projectId> <taskId> --json` |
| 「给任务加条备注」 | `dida task comment add <projectId> <taskId> --title "..."` |
| 「新建清单 / 标签」 | `dida project create --name "..."` / `dida tag create --name x --label x` |

不确定某个 flag 时**不要猜**，跑 `dida <cmd> <subcmd> --help` —— 快、准、只读。

要用户在清单、标签、任务之间做选择时，先跑对应的 list，把候选连同未完成数一起摆出来再问。清单用 `dida project list`，收件箱不在里面，见坑 4。候选超过 5 个时，按相关度排序并标出推荐项。

## 两类待办

**用户要建任务但没说什么时候做时，问一句再建**，别默默替他决定。三种情况：

| 用户说了什么 | 是哪类 | 怎么建 |
| --- | --- | --- |
| 给了时刻（「明天 10 点」「下午三点半」） | 定时 | `--due-date "2026-09-22T10:00:00+0800"`，**不问** |
| 只给了哪天，或「明天有空做」 | 普通待办 | `--all-day` + 当天 00:00，不打标签 |
| 「不急」「夜里跑」「闲了再说」 | 闲时待办 | `--all-day` + 当天 00:00 + `--tags 闲时` |
| 什么都没说 | **问** | 见下方话术 |

话术（一句话问完，不要连问）：

```text
这条什么时候做？①给个时间点 ②白天有空做 ③夜里跑就行（闲时）
```

用户已经用「不急 / 有空 / 闲了 / 顺手」这类词表过态的，**直接归闲时，不要再问**——
反问已经说过的信息比不问更烦人。

```bash
D=2026-09-22                                    # 日期一律由 date 生成，见 §日期处理
dida task create --title "..." --project "$P" --due-date "${D}T10:00:00+0800"          # 定时
dida task create --title "..." --project "$P" --all-day --due-date "${D}T00:00:00+0800"   # 普通
dida task create --title "..." --project "$P" --all-day --due-date "${D}T00:00:00+0800" --tags 闲时   # 闲时
```

**为什么要分**：`AI-Task` 清单被 ctr（本机调度台）每天 00:01 读走，按这个分类决定 worker
几点开跑——闲时的排进 **00:00-05:00**，普通的排进 **09:00-18:00**，给了时刻的就按那个时刻。
没有日期的任务 ctr 永远看不见，所以"要 AI 帮我跑"的待办必须有日期。

`闲时` 标签**已经建好了，别再建**（标签建了删不掉，见坑 8）；`--tags` 传标签名即可。

## 九个坑（全部实测坐实，多数踩中不会报错）

每个坑都标了**闭坑**动作，三档含义：`✅ 可根治`＝照做就不会再踩；`⚠️ 只能规避`＝多做一步绕开，机制本身改不了；`❌ 闭不了`＝只能事前避免或事后去 App 收拾。高频三条已封装成函数，见 §闭坑封装。

### 1. `task update` 必须把 taskId 写两遍，且 `--project` 必填

```bash
dida task update <taskId> --id <taskId> --project <projectId> --title "新标题"
```
少 `--id` 直接报 `error: required option '--id <id>' not specified`（这个还算友好，会报错）。

**闭坑 ✅**：永远用 `dida_update` 封装函数（见 §闭坑封装），不手拼 `task update`。

### 2. 日期格式不完整会被**静默丢弃**

`--due-date` / `--start-date` 必须是完整的 `yyyy-MM-ddTHH:mm:ss±ZZZZ`。传 `2026-09-21` 或任意乱码时：**不报错、exit 0、返回一个看起来成功的 JSON，但值原封不动**。

```bash
# ✅ 正确
--due-date "2026-09-20T18:00:00+0800"    # 本地时区，存为 10:00 UTC，转换正确
--due-date "2026-09-20T10:00:00Z"
# ❌ 静默无效
--due-date "2026-09-20"
```

改完时间后**必须回读确认**：`dida task get <projectId> <taskId> --json | grep dueDate`。

**闭坑 ✅**：日期一律由 `date` 生成而不是手打，且改完**必须回读比对**——用 `dida_setdue` 封装函数，它内置回读校验，值没变直接报错而不是静默通过。

### 3. `task search` 是坏的 —— 恒返回空

本账号下任何参数组合（含全字标题、不带关键词只带 `--projects`）都返回 `未找到匹配的任务。` / `[]`，而同条件的 `filter` 能正常返回。**不要用 search**，改用：

```bash
dida task filter --status 0 --json | python3 -c "
import json,sys
kw='关键词'
for t in json.load(sys.stdin):
    if kw in t.get('title','') or kw in t.get('content',''):
        print(t['projectId'], t['id'], t['title'])
"
```

**闭坑 ✅**：把 `task search` 当作不存在，一律走 `dida_find` 封装函数（filter 全量 + 本地匹配，顺带搜正文）。

### 4. 收件箱不在 `project list` 里

收件箱 projectId 形如 `inbox<数字>`，`dida project list` **不返回它**，但里面常有任务。要取：

```bash
dida task filter --status 0 --json | grep -o '"projectId": "inbox[0-9]*"' | head -1
```

**闭坑 ✅**：**不要遍历 `project list` 凑全量**——`dida task filter --status 0` 不带 `--projects` 就是含收件箱的跨清单全量。只有要操作收件箱本身时才去取它的 id。

### 5. `delete` 之后 `task get` 仍能读到

删除进的是垃圾桶，按 id 仍可 `get` 出内容。判断「真的没了」以 `task filter` / `project data` 为准，不要用 `get` 的返回当证据。

**闭坑 ✅**：存在性只认 `task filter` / `project data`，`task get` 永远不作为「还在不在」的证据——它只回答「内容是什么」。

### 6. 优先级只有 4 档，没有 2 和 4

`0=无  1=低  3=中  5=高`。传 2 或 4 不会得到预期结果。状态码：`0=未完成  2=已完成`。

**闭坑 ✅**：用户说「中优先级」映射到 `3` 不是 `2`；回报给用户时反向映射成中文，别把裸数字念出去。

### 7. `tag create --label` 必须等于 `--name`（只能差大小写）

help 把 `--label` 写成「标签显示名」，会让人以为可以自由取名。实际上 label 与 name 规范化后不一致就 **500 `tag label is invalid`**：

```bash
dida tag create --name skilltest --label skilltest     # ✅
dida tag create --name skilltest --label SkillTest     # ✅ 仅大小写不同
dida tag create --name "补测中文" --label "补测中文"     # ✅ 中文没问题
dida tag create --name skilltest --label "Skill补测"   # ❌ 500 tag label is invalid
```

`--label` 还是必填，省略报 `required option '--label <label>' not specified`。

**闭坑 ✅**：`--label` 永远传 `--name` 的同一个值，不试图取别的显示名：`N=标签名; dida tag create --name "$N" --label "$N"`。

### 8. 标签只能建不能删；全天任务日期显示早一天

- `dida tag` 只有 `list` / `create` 两个子命令，**没有 delete**——而且这不是 CLI 偷懒，是 **open API v1 本身就没有**：`OPTIONS /open/v1/tag` 返回 `allow: PUT,GET,HEAD,POST,OPTIONS`，`DELETE` 打过去是 `Request method 'DELETE' not supported`（500）。标签删除只存在于未公开的 v2 web API，那套要网页登录态，不是 OAuth token。
  **闭坑 ❌**（机制上闭不了）：建标签前先 `dida tag list` 查同名近义的；**绝不为了试参数去建标签**——建错就只能去 App「设置 → 标签管理」手删。已经建错的如实告知用户，别装没发生。
  顺带：`PUT /open/v1/tag` 是 CLI 未暴露的能力，可改 `label` / `sortOrder` / `sortType` / `parent` / `type`，但**改不了 `name`**（name 是主键，传 `newName` 被静默忽略）。
- `--all-day` 任务传 `2026-09-20T00:00:00+0800`，存为 `2026-09-19T16:00:00.000+0000`，默认输出打印这个 UTC 原文，看起来像 **09-19**。转换本身是对的，只是显示误导。
  **闭坑 ⚠️**（只能规避）：转述给用户前换回本地时区再念：`date -jf "%Y-%m-%dT%H:%M:%S%z" "2026-09-19T16:00:00+0000" +"%Y-%m-%d %H:%M"`。
  顺带一个**读**的时候要知道的（2026-09-21 实测）：全天任务的 `startDate` 与 `dueDate` **同值**，
  都是当天本地 00:00（建 09-22 的全天任务，两个字段都是 `2026-09-21T16:00:00.000+0000`）。
  `dueDate` 不是排他上界，判断"这条是哪天的"读哪个字段都对。

### 9. 带 `--items` 的任务，描述要用 `--desc`

传了 `--items`，任务 `kind` 就变成 `CHECKLIST`。App 的「描述」读 `desc` 字段，`content` 里写的东西不显示。`create` 返回和 `task get` 回读都能看到 content 有值，用户在 App 里看到的却是空描述。help 里 `--desc`「清单描述」指的是 checklist 模式的描述，不是清单（project）的描述。

**闭坑 ✅**：带 `--items` 时，描述一律走 `--desc`；纯文本任务才用 `--content`。回读时对照 `kind`：是 `CHECKLIST` 就查 `desc` 非空，是 `TEXT` 就查 `content`。

## 闭坑封装

高频三条用函数封死，别手拼。贴进 Bash 调用开头即可用。

> ⚠️ **本节代码块不能用 shell 位置参数**（`$` 紧跟数字那种写法）。SKILL.md 正文会被 skill 参数插值，
> 连这句警告本身也不能写出那个字面组合——写了就会被替换掉，警告自己先失效。
> 带 args invoke 时它们会被替换成 args 分词后的内容——2026-09-19 实测：传
> `在 2026-09-24 周四建一个任务：读召回观测结果`，渲染出的是
> `local p="2026-09-24" t="周四建一个任务：读召回观测结果"`，函数定义当场损坏且不报错，
> 照抄粘贴会对错误的 projectId 发写操作。**不带 args 时完全正常**，所以这个坑只在带参
> 调用时暴露，改本节前先想清楚这一点。`$@` 和 `${VAR:-默认}` 不受影响，可以用。
> 一律用 `DIDA_` 前缀的具名变量传参。

```bash
# 坑 1：taskId 写两遍 + --project 必填，一次封死
# 用法: DIDA_P=<projectId> DIDA_T=<taskId> dida_update --title "新标题"
dida_update() {
  dida task update "$DIDA_T" --id "$DIDA_T" --project "$DIDA_P" "$@" --json
}

# 坑 2：格式预校验 + 写后前后比对。不能只判「非空」——坑 2 的表现是「值原封不动」，
#       任务原本就有 dueDate 时判非空会假阳性
# 用法: DIDA_P=<projectId> DIDA_T=<taskId> DIDA_D="2026-09-20T18:00:00+0800" dida_setdue
dida_setdue() {
  local before after
  if ! printf '%s' "$DIDA_D" | grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}([+-][0-9]{4}|Z)$'; then
    echo "✗ 格式不合规，须为 yyyy-MM-ddTHH:mm:ss±ZZZZ 或 ...Z，已拒绝发送：$DIDA_D"; return 1
  fi
  before=$(dida task get "$DIDA_P" "$DIDA_T" --json | python3 -c "import json,sys;print(json.load(sys.stdin).get('dueDate',''))")
  dida_update --due-date "$DIDA_D" >/dev/null
  after=$(dida task get "$DIDA_P" "$DIDA_T" --json | python3 -c "import json,sys;print(json.load(sys.stdin).get('dueDate',''))")
  if [ -n "$after" ] && [ "$before" != "$after" ]; then echo "✓ dueDate: ${before:-(空)} → $after"
  elif [ "$before" = "$after" ] && [ -n "$after" ]; then echo "⚠ 值未变化（$after），确认是否本就是该值"; return 2
  else echo "✗ 未生效"; return 1; fi
}

# 坑 3：替代坏掉的 task search，标题与正文一起搜
# 用法: DIDA_KW=关键词 [DIDA_ST=0] dida_find
dida_find() {
  dida task filter --status "${DIDA_ST:-0}" --json | python3 -c "
import json, os, sys
kw = os.environ['DIDA_KW']
for t in json.load(sys.stdin):
    if kw in t.get('title', '') or kw in (t.get('content') or ''):
        print(t['projectId'], t['id'], t['title'])
"
}
```

`dida_setdue` 的回读校验是坑 2 唯一可靠的闭法——**写完不回读就等于没写**。

## 输出格式

默认输出是给人看的一行 `<id> [优先级] <标题>`，有截止时间的追加 ` 截止:<dueDate>`（UTC 原文，**全天任务会显示成前一天**，见坑 8）。**不含清单名、标签、子任务**。任何需要这些字段的判断，一律加 `--json`：

```bash
dida task filter --status 0 --json    # 完整对象：dueDate/tags/columnName/status/...
```

`task create` / `update` 成功后返回完整任务对象（含新 `id`），直接从返回里取 id，不用再查一次。

## 批量成一次调用

每条命令 <1s，贵的是往返而不是执行。需要多条时写进同一个 Bash 调用：

```bash
P=$(dida project list --json | python3 -c "import json,sys;print([p['id'] for p in json.load(sys.stdin) if p['name']=='待办'][0])")
dida task create --title "任务A" --project $P --priority 5
dida task create --title "任务B" --project $P
dida task filter --projects $P --status 0
```

## 写操作纪律

- **单条**建 / 改 / 完成 / 删：用户说了就直接做，不复问。
- **批量**（≥3 条，或一次删多条 / 跨清单移动）：先把要动的任务逐条回显（id + 标题 + 目标动作），列完即动手，给用户一帧打断的机会。
- **`project delete`**（删整个清单）：不删用户已有的清单，让用户自己在 App 里删；**自己为测试建的临时清单，用完自己删干净**，不留垃圾。
- 删除前先 `task get --json` 留一份内容在对话里，删错了能照着重建。

## 故障排除

| 现象 | 原因与处理 |
| --- | --- |
| `未登录` / 401 | token 失效 → 让用户 `! dida auth login` 重新授权 |
| 改了时间但没变 | 坑 2，日期格式不完整被静默丢弃，改成完整带时区格式 |
| `search` 找不到任务 | 坑 3，search 是坏的，改用 `filter --json` + 本地过滤 |
| `project list` 里找不到某任务所在清单 | 坑 4，它在收件箱 `inbox<数字>` |
| `required option '--id' not specified` | 坑 1，`update` 的 taskId 要写两遍 |
| 删了还能查到 | 坑 5，进了垃圾桶，以 `filter` 为准 |
| `500 tag label is invalid` | 坑 7，`--label` 必须等于 `--name`（仅大小写可不同）|
| 建错的标签删不掉 | 坑 8，CLI 无 `tag delete`，去 App 里删 |
| 全天任务日期差一天 | 坑 8，默认输出是 UTC 原文，按本地时区还原再报给用户 |
| App 里描述是空的，`get` 却有 content | 坑 9，带子任务的任务是 CHECKLIST，改用 `--desc` 写描述 |

## 验证状态

针对 `@suibiji/dida-cli@0.1.13` 实测。**下表未打勾的是从 `--help` / README 抄来的，用之前先 `--help` 核一遍再动手**，尤其写操作。

**已实测跑通**：`auth status` · `project list` · `project data` · `project create` · `project delete` · `task filter`（`--projects` / `--priority` / `--tag` / `--status` 各档均验证）· `task create`（含 `--items` / `--all-day` / `--repeat`）· `task update`（title / priority / due-date / tags）· `task complete` · `task delete` · `task get` · `task move`（源清单、目标清单、projectId 三重回读）· `task completed` · `task comment list|add` · `tag list` · `tag create`

**未实测**：`task create --reminders` · `task comment delete` · `project update|group|column` · `habit` / `focus` / `countdown`（不在本 skill 作用域）

## 版本历史

- v0.3.0（2026-09-21）：新增 §两类待办——建任务而用户没说时间时主动问一句，分成定时 / 普通 / 闲时三条路，闲时打 `闲时` 标签。这个分类有下游消费者：ctr 每天 00:01 读 `AI-Task`，闲时排进 00:00-05:00、普通排进 09:00-18:00。同时实测坐实全天任务的 `startDate` 与 `dueDate` 同值（补进坑 8），此前"`dueDate` 是排他上界"是推断且推错了。

- v0.2.1（2026-09-19）：修 §闭坑封装 三个函数的位置参数写法。SKILL.md 正文会被 skill 参数插值，带 args invoke 时 `$`+数字 会被替换成 args 分词内容，函数定义损坏且不报错、会对错误 projectId 发写操作（不带 args 时正常，故一直未暴露）。改用 `DIDA_` 前缀具名变量，并在该节加警告——警告文字本身也避开了那个字面组合，否则它自己也会被替换掉。三个函数改后实跑验证（正向命中、负向空）。

- v0.2.0（2026-09-18）：真实场景跑通后修订。修正三处自身错误（`!`cmd`` 动态日期语法本环境不展开、默认输出其实带截止时间、`project delete` 规则过绝对）；补测 `project create` / `tag create` / `--items` / `--all-day` / `--repeat` / `move` / `comment add` 并新增坑 7（tag label 必须等于 name）、坑 8（标签不可删 + 全天任务显示早一天）。
- v0.1.0（2026-09-18）：基础版，覆盖任务管理全链路（create/update/complete/delete/move/filter/completed/comment）+ 清单与标签读取。针对 `@suibiji/dida-cli@0.1.13` 实测，坑 1-6 均已 create→update→complete→delete 全链路验证。

---

---

---

<!-- BEGIN SELF-ITERATION v3 (由 ~/.claude/bin/skill-selfiter-sync.py 维护，勿手改) -->

## 自我迭代（就地留言板）

**用这个 skill 的过程中，任何改进提议随时 append 到同目录的 `CORRECTIONS.md`**（没有就新建）
——不必等收尾，想到就写；人和 AI 都能写。这份记录跟着 skill 走：换机器、分发出去、
同事装走都在，不依赖任何宿主的全局规则。

### 通道一：用户直接说（优先）

**执行完在回复末尾输出一行**，不提问、不等待、不打断：

```text
─ <skill 名> 完成。有要改的说一声，会记进它的 CORRECTIONS.md
```

用户随后说出「记一下… / 下次注意… / 以后要… / 这个 skill 要改… / 改一下这个 skill」
之类的话 → **立刻 append，不要追问、不要复述确认**。用户已经把要什么说清楚了，
写精简四字段就够：

```text
## <日期> · <一句话>
来源: 用户主动提出
原话: 「<逐字引用，不改写>」
skill patch 提议: <本文件哪一节加 / 改哪句话，具体到节>
```

### 通道二：AI 自扫（兜底）

用户没明说，但本次出现以下任一信号，也要记：①用户中断（Request interrupted）
②纠正词：错了 / 不对 / 应该 / 改成 / 其实是 ③倒逼补步骤："XX 了吗 / 查一下 / 传一下"
④我推的方案被推翻。这种情况写六字段，根因必须回答"为什么第一轮就该做对"——
那是可复用的规则拆解，不是道歉：

```text
## <日期> · <场景一句话>
来源: AI 自扫
上下文:<在做什么>
纠正类型:规则违反 | 步骤跳过 | 判断偏差 | 遗漏动作
现象:<第一轮做了什么>
纠正:<用户拉回什么（原话或概括）>
根因:<为什么第一轮就该做对>
skill patch 提议:<本文件哪一节加 / 改哪句话，具体到节>
```

### 铁律

- **只写 `CORRECTIONS.md`，不动本文件正文**——正文由复盘时人工升格，避免自动改写搅乱规范
- **两个通道都没命中就静默跳过**：不刷噪声、不凑数、不为了"有产出"编一条
- **`来源` 字段必填**，它区分"用户要求"和"AI 猜的"，回流合并时这两类权重完全不同
- 若本 skill 所在目录是 git 仓，entry 写完**顺带 `git add` 那一个文件**，别让它烂在本地——
  这份记录的价值在于汇回源仓，让下一个用它的人少踩一次

<!-- END SELF-ITERATION -->
