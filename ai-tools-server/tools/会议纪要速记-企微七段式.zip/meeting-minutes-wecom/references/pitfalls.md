# 踩坑记录（执行前快速浏览，避免重蹈覆辙）

按时间顺序沉淀的真实事故与规避方法。渲染 docx 前与执行 wecom-cli 前各过一遍。

## A. 渲染 docx 相关

1. **用 venv Python 运行渲染脚本**
   - 必须用带 python-docx 的解释器，例如某个带 python-docx 的 venv 解释器（裸解释器通常无 docx 模块）。
   - 脚本输出目录若叫 `docx/` 且工作目录下存在，会干扰某些 import；用带 venv 的 python 即可规避。
2. **文本中的英文双引号**
   - 直接写进 JSON 值没问题（JSON 转义合法），但人工拼 JSONL/字符串时最容易错；统一用中文引号「“ ”」或「『』」更安全，避免半角 `"` 破坏结构。
3. **列表编号双编号**
   - `add_paragraph` 不要同时用 Word 的 List Number 样式 + 字面编号（会渲染成 `1.1.`）。一律普通段落 + 字面前缀（`• ` / `1.` / `1）`）。
4. **表格左对齐**
   - 企微 doc 内渲染约定是表格整体与单元格内容**全部左对齐**。build_minutes_docx.py 已在保存前统一处理；若绕过脚本手写 docx，必须补 `WD_TABLE_ALIGNMENT.LEFT` + 每单元格段落 `WD_ALIGN_PARAGRAPH.LEFT`。
5. **标题层级**：add_heading 不要用 `doc.add_heading(text, level)` 混跑——统一走本 skill 脚本的 add_heading（level 1 段落 + Heading 1 样式，run 加粗），七段主标题全部 level 1。

## B. 导入企微 doc

6. **必须 docx → import 两步，禁止用 doc create 的 content 参数**：`doc create` 的 `content` 参数创建的文档 API 能读到内容但客户端渲染为空（用户实测反馈）。统一：本地生成 docx → `doc import`。
7. **import 时 `file_name` 必须与文档标题一致**（含 `.docx` 后缀），否则企微侧文档名不对。
8. **docid 提取**：import 返回 `url`，docid 从 `https://doc.weixin.qq.com/doc/<docid>` 中提取（`/doc/` 后、`?` 前）。后续 contents get / members update 都靠它。
9. **权限会过期**：`wecom-cli` 通讯录/文档权限偶发过期，命令报权限类错误时，请用户在企业微信点授权链接/重新扫码（`wecom-cli auth show --status` 先自查），修复后再重试 import，不要反复撞错。
10. **contents get 校验配额**：读取文档内容验证当天有配额限制；验证失败先看是否配额问题，可稍后重试或改用文本比对本地内容兜底。
11. **导入后客户端同步**：导入成功的文档可能在客户端「文档中心」可见；用户需要把在线文档归入微盘「我的空间/04-会议纪要/26 年」时，CLI 无法直接移动（无 folder/space 参数），需用户客户端手动操作——在交付时提醒。

## C. 权限邀请（doc members update）

12. 参数：`{"docid":"...","add_member_list":{"items":[{"userid":"...","user_type":"user","user_auth":"edit"}]}}`。
    - `user_auth` 枚举：`manager` 管理员 / `edit` 可编辑 / `read` 仅浏览。
    - 默认邀请为**可编辑（edit）**；仅当用户明确说「仅浏览/只读」时用 `read`。
13. userid 一律来自 wecomcli-contact 查询结果，禁止凭记忆拼接（姓名≠userid）。一个 userid 可对应中文名/英文名/别名，按官方 name 展示。

## D. 流程与清理约定

14. **V5 清理约定**：企微 doc 导入成功且 contents get 验证七段齐全后，**立即删除本地中间产物**——工作目录下的 `<标题>.json`（或 jsonl）与 `docx/` 目录（含全部 docx）。企微在线文档是唯一留存；用户需要本地备份会另行导出。
15. **ID 不外露**：最终回复不得出现 docid / userid / department_id 等内部标识，只用文档链接 + 可读名称。
16. 生成 docx 前先确认目标输出目录与 JSON 动作文件路径都写清楚；actions JSON 若文件名含空格/中文，命令用引号包裹。

## E. 文档加入规则（doc rules update）

17. **每次 doc import 成功后必做（2026-09-08 用户约定，默认开启，无需再问）**：`enable_member_join_admin_check: true` 开启「成员加入需要确认」——外部通过链接申请加入文档时需管理员确认，防止陌生人直接进入。
    - 命令：`wecom-cli doc rules update --json '{"docid":"<docid>","enable_member_join_admin_check":true}'`，成功返回空对象。
    - `corp_internal_join_auth` / `corp_external_join_auth` 仅在 `enable_member_join_admin_check=false` 时生效；开启确认后无需传。
    - 顺序：import 拿到 docid → rules update → contents get 校验 → 邀请成员（受邀成员直接进入，不受加入确认影响）。
