---
name: meeting-minutes-wecom
description: 会议纪要「七段式」总结并归档为企业微信在线文档的完整工作流。当用户提交会议原文文件（.txt/粘贴文本/转写稿）并要求总结成企微在线文档、会议纪要、七段式纪要，或说「帮我总结这份会议记录」「整理成会议纪要归档」「邀请参会人」时使用。流程：提炼标题与时间 → 企微通讯录人名实名纠错 → 生成七段式内容（核心结论/基本信息表格/关键议题/讨论详情/待办/遗留议题/其他）→ 本地渲染左对齐 docx → 导入企微 doc（禁止 doc create content）→ 校验七段齐全 → 按用户要求邀请参会人权限（默认可编辑）→ 删除本地中间产物，交付在线文档链接。依赖企业微信 wecom-cli（wecomcli-shared/contact/doc/doc-manage 连接器技能）与本地 python-docx 渲染脚本。
agent_created: true
---

# 会议纪要七段式总结并归档企业微信在线文档

把一份杂乱的会议原文，加工成排版统一的企微在线文档（doc），交付可分享链接，并可选邀请参会人编辑。本 skill 沉淀了用户多轮迭代锁定的格式约定（V5 定版），**输出必须严格贴合约定，不要自由发挥**。

## 适用场景（触发词）

- 用户提交会议纪要原文/会议转写 txt，要求总结、整理、出纪要、归档企微文档。
- 用户提供 `https://doc.weixin.qq.com/doc/...` 之外的原文（文件或粘贴），意图是「新生成一份结构化会议纪要」。
- 用户要求在既有纪要上「邀请参会人」「再校验一遍七段」。

不适用：用户要给的是智能文档 smartpage / 在线表格 / 需求池等，路由到对应技能。

## 前置依赖（开始前确认）

1. 企微连接器技能（执行任何 `wecom-cli` 前先完成 **wecomcli-shared** 前置检查：`wecom-cli --version` ≥ 1.1.0、`wecom-cli auth show --status` = authorized；缺失则按 wecomcli-shared 指引安装/授权）：
   - **wecomcli-contact**：通讯录人名搜索（人名纠错必需）
   - **wecomcli-doc**：`doc import` / `doc contents get`
   - **wecomcli-doc-manage**：`doc rules update` 设置加入规则（每次创建文档后必做：开启成员加入确认）+ `doc members update` 邀请权限（仅当需要邀请时）
2. 本地渲染环境：带 python-docx 的 venv，推荐一个带 python-docx 的 venv 解释器（不存在则 `python3 -m venv` 创建并 `pip install python-docx`）。
3. 明确输出工作目录（本次任务的项目目录即可）与会议时间（原文有则用原文，无则用执行日）。

## 执行流程（按序）

### Step 1 读取原文，确定标题与时间
- 读取原文文件（UTF-8；若乱码试 GBK）。
- 提炼主题 → 标题 = `MM-DD 主题`（MM-DD 取会议时间，无则执行日）。主题命名参照 09-03 基准样式：`业务对象 + 内容/动作`（如「零售业务8月经营复盘和9月规划」），少用「XX日会」这类只描述会议形式的名字。
- 记录会议时间/时长/地点/主持人等可用信息（推断参会人清单）。

### Step 2 人名与企微通讯录对齐
- 通读原文，抽取出**所有人名/疑似人名/称呼**（含错别字、别名、外号、英文名）。
- 逐个调用 wecomcli-contact `contact users search`（关键词支持姓名/拼音/英文名/别名）。
- 命中 → 记录官方 name、职务（position/departments）、userid（内部流转用）；参会人与正文一律替换为官方姓名；**展示时优先花名/惯用称呼，不并列实名**（2026-09-08 约定：禁止「花名（实名，…）」式花名+实名并列；无花名才展示实名）。
- 未命中 → 保留原文，不臆测。
- 常见别名映射可参考 references/seven-section-template.md 第 2 节（仅加速，以当次查询为准）。

### Step 3 生成七段式内容
- 先读 references/sample-0903.md（格式基准样本文档副本，内容为脱敏示例）对照版式，再按 references/seven-section-template.md 模板逐段撰写：
  首行大标题(MM-DD 主题) → 一、核心结论(≤140字整段) → 二、会议基本信息(两列表格含字段/内容表头、会议时长、记录来源) → 三、关键议题和共识(议题=加粗「N. 主题句」，决策用「决策内容/决策逻辑/后续影响」加粗引导) → 四、会议讨论详情(小节用 H2「N. 小节标题」) → 五、待办事项(无前缀管道行 `优先级|事项|@负责人|期限`) → 六、遗留和搁置议题(两列表格：遗留/搁置议题|当前状态与说明) → 七、其他(编号列表，含人名/名词转写修正记录等)。
- 将内容组织为 actions JSON（`{"title","actions":[...]}`，schema 与示例见 template 第 3 节），写入工作目录 `<标题>.json`。

### Step 4 渲染本地 docx
- 浏览 references/pitfalls.md 的 A 组条目。
- 运行：`<venv-python> <skill>/scripts/build_minutes_docx.py "<标题>.json" <工作目录>/docx`
- 产出 `<工作目录>/docx/<标题>.docx`（脚本已自动做表格左对齐，无需后处理）。

### Step 5 导入企微 doc
- 完成 wecomcli-shared 前置检查（或先自查），再按 wecomcli-doc 的 import 接口执行：
  `wecom-cli doc import --json '{"doc_type":"doc","file_name":"<标题>.docx","file_path":"<docx绝对路径>"}'`
- `file_name` 必须与标题一致；从返回 url 中提取 docid（`/doc/` 后、`?` 前）。

### Step 6 校验七段齐全
- `wecom-cli doc contents get --json '{"docid":"<docid>","content_type":"text"}'`
- 校验七段标题都在、人名已实名、待办/表格无异常；缺段或内容错 → 修正 actions JSON 重新渲染并 import（覆盖或删除旧文档需用户确认）。

### Step 7 邀请参会人权限（用户要求时）
- 默认**可编辑**（`user_auth":"edit"`）；用户说「仅浏览/只读」→ `read`。
- 参会 userid 全部来自 Step 2 通讯录查询；按 wecomcli-doc-manage 的 members update 接口批量添加：
  `wecom-cli doc members update --json '{"docid":"<docid>","add_member_list":{"items":[{"userid":"...","user_type":"user","user_auth":"edit"}]}}'`

### Step 8 清理本地产物（V5 约定）
- 校验通过后：删除 `<标题>.json` 与整个 `docx/` 输出目录（企微在线文档为唯一留存）。用户明确要本地备份则跳过并说明。

### Step 9 交付
- 回复中给出 `[标题](在线文档链接)`，一句话核心结论 + 待办条数摘要。
- 提醒：如需把文档归入微盘「我的空间/04-会议纪要/26 年」需在企微客户端手动移动（CLI 不支持）。
- 遵守 ID 不外露约束（docid/userid 只在内部流转）。

## 包内资源

| 资源 | 用途 |
|---|---|
| `scripts/build_minutes_docx.py` | actions JSON → 左对齐 .docx（自包含，仅依赖 python-docx；用法见脚本 docstring） |
| `references/seven-section-template.md` | 七段式排版定版约定（对齐 09-03 基准样式）+ actions JSON 示例 + 常见人名别名映射 |
| `references/sample-0903.md` | 「内容格式与标题样式」基准样本文档《09-03 仓店零售8月经营复盘和9月规划》的 markdown 副本（**内容已脱敏为示例数据**，生成前对照版式） |
| `references/pitfalls.md` | 渲染/导入/邀请/清理全过程踩坑记录（执行前浏览） |

## 常见命令速查（准确参数以加载后的 connector skill 为准）

```bash
# 通讯录搜索人名
wecom-cli contact users search --json '{"keywords":["某员工姓名"]}'
# 导入 docx
wecom-cli doc import --json '{"doc_type":"doc","file_name":"08-28 主题.docx","file_path":"/abs/path/08-28 主题.docx"}'
# 读文档内容校验
wecom-cli doc contents get --json '{"docid":"<docid>","content_type":"text"}'
# 设置加入规则：开启成员加入需要确认（创建后必做）
wecom-cli doc rules update --json '{"docid":"<docid>","enable_member_join_admin_check":true}'
# 邀请成员（edit/read/manager）
wecom-cli doc members update --json '{"docid":"<docid>","add_member_list":{"items":[{"userid":"<userid>","user_type":"user","user_auth":"edit"}]}}'
```
