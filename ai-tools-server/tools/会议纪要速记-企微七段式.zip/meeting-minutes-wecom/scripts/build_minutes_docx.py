#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_minutes_docx.py — 会议纪要 actions JSON → 企微友好 .docx

会议纪要 skill (meeting-minutes-wecom) 的本地渲染脚本。自包含、无第三方依赖
（仅 python-docx）。把结构化的 actions 列表渲染成一份 .docx，并自动保证：
  * 所有表格整体左对齐（WD_TABLE_ALIGNMENT.LEFT）
  * 表格内所有单元格段落左对齐（WD_ALIGN_PARAGRAPH.LEFT）
  * 表格首行自动加粗（视为表头）
导入企微 doc 后即为已左对齐的成品，无需再做后处理。

用法:
  python build_minutes_docx.py <actions.json> <output_dir> [doc_title]
  或从 stdin 读取（第一个参数传 -）:
  cat actions.json | python build_minutes_docx.py - <output_dir> [doc_title]

actions.json 结构:
{
  "title": "08-28 某业务线方案与工具链协同讨论",   // 可选，doc_title 缺省时使用
  "actions": [
    {"action": "add_heading",  "params": {"text": "核心结论", "level": 1}},
    {"action": "add_paragraph","params": {"runs": [{"text": "会议就……达成一致。", "bold": false}]}},
    {"action": "add_paragraph","params": {"text": "纯文本段落同样支持"}},
    {"action": "add_table",    "params": {"data": [["会议主题","…"],["时间","…"]], "header": true}}
  ]
}

支持 action:
  add_heading   params: text(string, 必填), level(int, 1-3, 默认 1)
  add_paragraph params: runs(数组[{text,bold,size}]) 或 text(纯文本); bullet=false 不用(用字面"• "前缀)
  add_table     params: data(二维数组, 必填), header(bool, 默认 true -> 首行加粗)

注意:
  * 段落文本中的双引号请使用中文引号或确保 JSON 合法转义。
  * 待办/列表一律用普通段落 + 字面前缀（如 "• "），不要用 Word 的 List Number/Bullet
    样式，避免 import 后出现 1.1. 双编号或样式错乱。
"""
import json
import os
import sys


def _norm_runs(text_or_runs):
    """兼容 runs 数组与纯文本两种写法。"""
    if isinstance(text_or_runs, str):
        return [{"text": text_or_runs, "bold": False}]
    if isinstance(text_or_runs, list):
        out = []
        for r in text_or_runs:
            if isinstance(r, str):
                out.append({"text": r, "bold": False})
            else:
                out.append(r)
        return out
    return []


def _safe_filename(name):
    return name.replace("/", "／").replace("\\", "＼").replace(":", "：").strip()


def build(data, out_dir, doc_title=None):
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt

    title = doc_title or data.get("title") or "会议纪要"
    actions = data.get("actions") or data.get("blocks") or []

    doc = Document()
    # 中文友好：正文默认字体设为宋体/微软雅黑候选，避免部分查看器缺字
    try:
        style = doc.styles["Normal"]
        style.font.name = "Calibri"
        style.font.size = Pt(11)
    except Exception:
        pass

    for item in actions:
        act = item.get("action")
        p = item.get("params") or {}
        if act == "add_heading":
            level = int(p.get("level", 1))
            style_name = {1: "Heading 1", 2: "Heading 2", 3: "Heading 3"}.get(
                level, "Heading 1"
            )
            h = doc.add_paragraph(style=style_name)
            h.add_run(p.get("text", "")).bold = True
        elif act == "add_paragraph":
            para = doc.add_paragraph()
            for r in _norm_runs(p.get("runs") if "runs" in p else p.get("text", "")):
                run = para.add_run(r.get("text", ""))
                run.bold = bool(r.get("bold", False))
                if r.get("size"):
                    try:
                        run.font.size = Pt(float(r["size"]))
                    except Exception:
                        pass
        elif act == "add_table":
            data_rows = p.get("data") or []
            if not data_rows:
                continue
            header = p.get("header", True)
            try:
                table = doc.add_table(rows=0, cols=len(data_rows[0]))
                table.style = "Table Grid"
            except Exception:
                table = doc.add_table(rows=0, cols=len(data_rows[0]))
            for ridx, row in enumerate(data_rows):
                cells = table.add_row().cells
                for cidx, val in enumerate(row):
                    if cidx >= len(cells):
                        break
                    cell = cells[cidx]
                    cell.paragraphs[0].text = ""
                    run = cell.paragraphs[0].add_run(str(val))
                    if header and ridx == 0:
                        run.bold = True
            # 表格整体左对齐 + 单元格段落左对齐（既定排版约定）
            table.alignment = WD_TABLE_ALIGNMENT.LEFT
            for row in table.rows:
                for cell in row.cells:
                    for para in cell.paragraphs:
                        para.alignment = WD_ALIGN_PARAGRAPH.LEFT
        else:
            raise ValueError(f"未知 action: {act}")

    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{_safe_filename(title)}.docx")
    doc.save(path)
    return path


def main():
    if len(sys.argv) < 3:
        print(
            "用法: python build_minutes_docx.py <actions.json | ->stdin> <output_dir> [doc_title]",
            file=sys.stderr,
        )
        sys.exit(2)
    src, out_dir = sys.argv[1], sys.argv[2]
    doc_title = sys.argv[3] if len(sys.argv) > 3 else None
    if src == "-":
        data = json.load(sys.stdin)
    else:
        with open(src, "r", encoding="utf-8") as f:
            data = json.load(f)
    path = build(data, out_dir, doc_title)
    print(path)


if __name__ == "__main__":
    main()
