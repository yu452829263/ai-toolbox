#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
广告法极限词/绝对化用语兜底扫描脚本。

用途：读取一份脚本文案（文件或 stdin），对照 references/banned-words.txt 词库，
扫描命中的高风险词并标注位置，输出 JSON 报告。作为语义审查的兜底初筛，
不替代 LLM 的语义判断（很多风险需理解语境）。

用法：
  python scan_banned_words.py input_script.txt
  cat input_script.txt | python scan_banned_words.py -
  python scan_banned_words.py input_script.txt --format text
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORD_LIST = os.path.join(HERE, "..", "references", "banned-words.txt")


def load_words(path):
    words = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            w = line.strip()
            if w and not w.startswith("#"):
                words.append(w)
    # 长词优先，避免"最"抢先匹配"最便宜"
    return sorted(set(words), key=len, reverse=True)


def scan(text, words):
    hits = []
    for i, line in enumerate(text.splitlines(), start=1):
        for w in words:
            start = 0
            while True:
                idx = line.find(w, start)
                if idx == -1:
                    break
                hits.append({
                    "line": i,
                    "column": idx + 1,
                    "word": w,
                    "context": line[max(0, idx - 10): idx + len(w) + 10],
                })
                start = idx + len(w)
    return hits


def dedup(hits):
    """去掉被更长命中完全覆盖的短词命中（如'最便宜'已命中，则不再单独报'最'）。"""
    by_line = {}
    for h in hits:
        by_line.setdefault(h["line"], []).append(h)
    result = []
    for line, lst in by_line.items():
        lst.sort(key=lambda x: (x["column"], -len(x["word"])))
        kept = []
        for h in lst:
            covered = False
            for k in kept:
                if k["column"] <= h["column"] and (k["column"] + len(k["word"])) >= (h["column"] + len(h["word"])):
                    covered = True
                    break
            if not covered:
                kept.append(h)
        result.extend(kept)
    result.sort(key=lambda x: (x["line"], x["column"]))
    return result


def main():
    ap = argparse.ArgumentParser(description="广告法极限词兜底扫描")
    ap.add_argument("input", help="脚本文案文件路径，或用 - 表示 stdin")
    ap.add_argument("--format", choices=["json", "text"], default="json")
    args = ap.parse_args()

    if args.input == "-":
        text = sys.stdin.read()
    else:
        with open(args.input, "r", encoding="utf-8") as f:
            text = f.read()

    words = load_words(WORD_LIST)
    hits = dedup(scan(text, words))

    if args.format == "text":
        if not hits:
            print("未发现词库命中的极限词。")
        else:
            for h in hits:
                print(f"[第{h['line']}行:{h['column']}列] 命中「{h['word']}」 上下文：…{h['context']}…")
    else:
        print(json.dumps({
            "total": len(hits),
            "hits": hits,
        }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
