# Complete Command Reference

## ical calendars

Manage calendars. Running without a subcommand lists all calendars.

```bash
ical calendars
ical cals
ical calendars -o json
```

Aliases: `cals`

### ical calendars create

Create a new calendar. Title can be passed as a positional argument or via `--title`.

```bash
ical calendars create "Projects" --source iCloud --color "#FF6961"
ical calendars create -i
```

| Flag              | Short | Description                                | Default |
| ----------------- | ----- | ------------------------------------------ | ------- |
| `--title`         | `-T`  | Calendar title                             | —       |
| `--source`        | `-s`  | Account source (required, e.g., "iCloud")  | —       |
| `--color`         | —     | Calendar color (hex, e.g., "#FF6961")      | —       |
| `--interactive`   | `-i`  | Interactive mode with guided prompts       | false   |

Aliases: `add`, `new`

### ical calendars update

Update an existing calendar (rename, recolor). With no arguments, shows an interactive picker.

```bash
ical calendars update "Projects" --title "Archived" --color "#8295AF"
ical calendars update "Projects" -i
ical calendars update -i
```

| Flag              | Short | Description                              | Default |
| ----------------- | ----- | ---------------------------------------- | ------- |
| `--title`         | `-T`  | New calendar title                       | —       |
| `--color`         | —     | New calendar color (hex)                 | —       |
| `--interactive`   | `-i`  | Interactive mode with guided prompts     | false   |

Aliases: `edit`, `rename`

### ical calendars delete

Permanently delete a calendar and all its events. With no arguments, shows an interactive picker.

```bash
ical calendars delete "Projects"
ical calendars delete "Projects" --force
ical calendars delete
```

| Flag      | Short | Description              | Default |
| --------- | ----- | ------------------------ | ------- |
| `--force` | `-f`  | Skip confirmation prompt | false   |

Aliases: `rm`, `remove`

---

## ical list

List events within a date range. Defaults to today if no range specified.

```bash
ical list
ical list --from today --to "next friday"
ical list --calendar Work --sort title
ical ls --from "mar 1" --to "mar 31" --all-day
ical list --from today --to "in 30 days" --exclude-calendar Birthdays -o json
```

| Flag                 | Short | Description                                     | Default         |
| -------------------- | ----- | ----------------------------------------------- | --------------- |
| `--from`             | `-f`  | Start date (natural language or ISO 8601)       | Today           |
| `--to`               | `-t`  | End date (natural language or ISO 8601)         | From + 24 hours |
| `--calendar`         | `-c`  | Filter by calendar name (repeatable)            | All calendars   |
| `--calendar-id`      | —     | Filter by calendar ID                           | —               |
| `--search`           | `-s`  | Search title, location, notes                   | —               |
| `--all-day`          | —     | Show only all-day events                        | false           |
| `--sort`             | —     | Sort by: start, end, title, calendar            | start           |
| `--limit`            | `-n`  | Max events to display (0 = unlimited)           | 0               |
| `--exclude-calendar` | —     | Exclude calendars by name (repeatable)          | —               |
| `--attendee`         | `-a`  | Filter by attendee or organizer name/email      | —               |
| `--no-recurring`     | —     | Hide recurring events                           | false           |

Aliases: `ls`, `events`

---

## ical today

Show today's events. Shortcut for `ical list --from today --to tomorrow`.

```bash
ical today
ical today --calendar Work
ical today -o json
ical today --exclude-calendar Birthdays
```

| Flag                 | Short | Description                                | Default       |
| -------------------- | ----- | ------------------------------------------ | ------------- |
| `--calendar`         | `-c`  | Filter by calendar name (repeatable)       | All calendars |
| `--calendar-id`      | —     | Filter by calendar ID                      | —             |
| `--search`           | `-s`  | Search title, location, notes              | —             |
| `--all-day`          | —     | Show only all-day events                   | false         |
| `--sort`             | —     | Sort by: start, end, title, calendar       | start         |
| `--limit`            | `-n`  | Max events to display (0 = unlimited)      | 0             |
| `--exclude-calendar` | —     | Exclude calendars by name (repeatable)     | —             |
| `--attendee`         | `-a`  | Filter by attendee or organizer name/email | —             |
| `--no-recurring`     | —     | Hide recurring events                      | false         |

---

## ical upcoming

Show events in the next N days. Shortcut for `ical list --from today --to "in N days"`.

```bash
ical upcoming
ical upcoming --days 14
ical upcoming --calendar Work -o json
ical next --days 3
```

| Flag                 | Short | Description                                | Default       |
| -------------------- | ----- | ------------------------------------------ | ------------- |
| `--days`             | `-d`  | Number of days to look ahead               | 7             |
| `--calendar`         | `-c`  | Filter by calendar name (repeatable)       | All calendars |
| `--calendar-id`      | —     | Filter by calendar ID                      | —             |
| `--search`           | `-s`  | Search title, location, notes              | —             |
| `--all-day`          | —     | Show only all-day events                   | false         |
| `--sort`             | —     | Sort by: start, end, title, calendar       | start         |
| `--limit`            | `-n`  | Max events to display (0 = unlimited)      | 0             |
| `--exclude-calendar` | —     | Exclude calendars by name (repeatable)     | —             |
| `--attendee`         | `-a`  | Filter by attendee or organizer name/email | —             |
| `--no-recurring`     | —     | Hide recurring events                      | false         |

Aliases: `next`, `soon`

---

## ical show

Display full details for a single event. With no arguments, shows an interactive picker.

```bash
ical show 2                                      # Row number from last listing
ical show                                        # Interactive event picker
ical show ABC12345 -o json                       # Full or partial event ID
ical show --id "577B8983-DF44:ABC123" -o json   # Exact event ID (agents: use this)
```

| Flag     | Short | Description                                  | Default |
| -------- | ----- | -------------------------------------------- | ------- |
| `--id`   | —     | Full event ID (exact match, no prefix search) | —       |
| `--from` | `-f`  | Start date for event picker                  | Today   |
| `--to`   | `-t`  | End date for event picker                    | —       |
| `--days` | `-d`  | Number of days to show in picker             | 7       |

Event selection methods:

1. **No argument** — interactive huh picker of upcoming events
2. **Number** (e.g., `2`) — row number from the last `list`/`today`/`upcoming` output
3. **String** — full or partial event ID (positional arg)
4. **`--id`** — full event ID, exact match only (preferred for scripts/agents)

> `--id` and a positional argument are mutually exclusive — passing both is an error.

Aliases: `get`, `info`

---

## ical add

Create a new calendar event. Title can be passed as a positional argument or via `--title`.

```bash
ical add "Team standup" --start "tomorrow at 9am" --end "tomorrow at 9:30am" --calendar Work
ical add --title "Lunch" --start "today at noon" --end "today at 1pm" --location "Cafe"
ical add "Flight" --start "mar 15 at 8am" --end "mar 15 at 11am" --alert 1h --alert 1d
ical add "Weekly sync" --start "next monday at 10am" --repeat weekly --repeat-days mon
ical add -i   # Interactive mode
```

| Flag                | Short | Description                                         | Default        |
| ------------------- | ----- | --------------------------------------------------- | -------------- |
| `--title`           | `-T`  | Event title                                         | —              |
| `--start`           | `-s`  | Start date/time (required)                          | —              |
| `--end`             | `-e`  | End date/time                                       | Start + 1 hour |
| `--all-day`         | `-a`  | Create as all-day event                             | false          |
| `--calendar`        | `-c`  | Calendar name                                       | System default |
| `--location`        | `-l`  | Location string                                     | —              |
| `--notes`           | `-n`  | Notes/description                                   | —              |
| `--url`             | `-u`  | URL to attach                                       | —              |
| `--alert`           | —     | Alert before event (e.g., 15m, 1h, 1d) — repeatable | —              |
| `--no-alert`        | —     | Create with zero alerts (overrides calendar default alerts) | false          |
| `--repeat`          | `-r`  | Recurrence: daily, weekly, monthly, yearly          | —              |
| `--repeat-interval` | —     | Recurrence interval                                 | 1              |
| `--repeat-until`    | —     | Recurrence end date (a bare date includes the whole day) | —              |
| `--repeat-count`    | —     | Number of occurrences                               | 0              |
| `--repeat-days`     | —     | Days for weekly recurrence (e.g., mon,wed,fri)      | —              |
| `--timezone`        | —     | IANA timezone (e.g., America/New_York)              | —              |
| `--invite`          | —     | Invite an attendee (`email` or `"Name <email>"`) — repeatable; sends an invitation | — |
| `--travel`          | —     | Travel time before the event (e.g., 30m, 1h)        | —              |
| `--interactive`     | `-i`  | Interactive mode with guided prompts                | false          |

`--invite` and `--travel` are not available with `-i`. Inviting an attendee makes the calendar account send a real invitation email on save, and the organizer (you) is added automatically.

Aliases: `create`, `new`

---

## ical update

Update an existing event. Only specified fields are changed.

```bash
ical update 2 --title "New title"
ical update 3 --start "tomorrow at 10am" --end "tomorrow at 11am"
ical update 1 --location ""              # Clear location
ical update 1 --alert none               # Clear alerts
ical update 1 --repeat none              # Remove recurrence
ical update 2 --span future --start "next monday at 9am"  # Update future occurrences
ical update -i                           # Interactive mode with picker
ical update --id "577B8983-DF44:ABC123" --title "New title"  # Exact ID (agents: use this)
```

| Flag                | Short | Description                                  | Default |
| ------------------- | ----- | -------------------------------------------- | ------- |
| `--id`              | —     | Full event ID (exact match, no prefix search) | —       |
| `--title`           | `-T`  | New title                                    | —       |
| `--start`           | `-s`  | New start date/time                          | —       |
| `--end`             | `-e`  | New end date/time                            | —       |
| `--all-day`         | `-a`  | Set all-day: "true" or "false"               | —       |
| `--calendar`        | `-c`  | Move to calendar (by name)                   | —       |
| `--location`        | `-l`  | New location (empty string to clear)         | —       |
| `--notes`           | `-n`  | New notes (empty string to clear)            | —       |
| `--url`             | `-u`  | New URL (empty string to clear)              | —       |
| `--alert`           | —     | Replace alerts (repeatable, `none` to clear) | —       |
| `--timezone`        | —     | New IANA timezone                            | —       |
| `--span`            | —     | For recurring: "this" or "future"            | this    |
| `--repeat`          | `-r`  | Set/change recurrence ("none" to remove)     | —       |
| `--repeat-interval` | —     | Change recurrence interval                   | 1       |
| `--repeat-until`    | —     | Change recurrence end date                   | —       |
| `--repeat-count`    | —     | Change recurrence count                      | 0       |
| `--repeat-days`     | —     | Change recurrence days                       | —       |
| `--interactive`     | `-i`  | Interactive mode with guided prompts         | false   |

Event selection: same as `show` (no args = picker, number = row, string = event ID, `--id` = exact).

> `--id` and a positional argument are mutually exclusive — passing both is an error.
> `update` has **no** `--force` flag and requires no confirmation — changes apply immediately.

Aliases: `edit`

---

## ical delete

Delete one or more events. Asks for confirmation by default.

```bash
ical delete 1 --force                              # Row number, skip confirmation
ical rm 2 --force                                  # Alias
ical delete 1 2 3 --force                          # Batch delete multiple events
ical delete                                        # Interactive picker
ical delete 3 --span future                        # Delete this and future occurrences
ical delete 3 --span all --force                   # Delete the entire recurring series
ical delete --id "577B8983-DF44:ABC123" --force   # Exact event ID (agents: use this)
```

| Flag      | Short | Description                                  | Default |
| --------- | ----- | -------------------------------------------- | ------- |
| `--id`    | —     | Full event ID (exact match, no prefix search) | —       |
| `--force` | `-f`  | Skip confirmation prompt                     | false   |
| `--span`  | —     | For recurring: "this", "future", or "all" (whole series) | this    |
| `--from`  | —     | Start date for event picker                  | Today   |
| `--to`    | —     | End date for event picker                    | —       |
| `--days`  | `-d`  | Number of days to show in picker             | 7       |

Event selection: same as `show` (no args = picker, number = row, string = event ID, `--id` = exact).

> `--id` and a positional argument are mutually exclusive — passing both is an error.
> `update` does **not** have a `--force` flag — it applies changes immediately without confirmation.

Aliases: `rm`, `remove`

---

## ical search

Search events by title, location, and notes within a date range.

```bash
ical search "meeting"
ical search "standup" --calendar Work
ical search "dentist" --from "jan 1" --to "dec 31" --limit 5
ical find "lunch" -o json
```

| Flag             | Short | Description                                | Default       |
| ---------------- | ----- | ------------------------------------------ | ------------- |
| `--from`         | `-f`  | Start of search range                      | 30 days ago   |
| `--to`           | `-t`  | End of search range                        | 30 days ahead |
| `--calendar`     | `-c`  | Filter by calendar name (repeatable)       | All calendars |
| `--attendee`     | `-a`  | Filter by attendee or organizer name/email | —             |
| `--no-recurring` | —     | Hide recurring events                      | false         |
| `--limit`        | `-n`  | Max results (0 = unlimited)                | 0             |

Aliases: `find`

---

## ical join

Open the video-conference link of the current or next meeting. With no argument, picks the event most likely wanted: one happening now (most recently started wins), otherwise the soonest upcoming event with a link, searched `--days` ahead. With an argument, resolves a row number or event ID like `show`.

```bash
ical join                 # open the current/next meeting link in the browser
ical join --print         # print just the URL (pipe-friendly, opens nothing)
ical join 3               # join the event at row 3 of the last listing
ical join -d 1            # only look 1 day ahead
ical join -o json         # full event JSON instead of opening
```

| Flag      | Short | Description                                      | Default |
| --------- | ----- | ------------------------------------------------ | ------- |
| `--print` | `-p`  | Print the conference link instead of opening it  | false   |
| `--days`  | `-d`  | How many days ahead to look for the next meeting | 7       |

Links are detected for Zoom, Google Meet, Teams, FaceTime, Webex, Jitsi, Whereby, Chime, and GoToMeeting, whether in the event's URL field, location, or notes. An event with no link errors.

---

## ical rsvp

Respond to an event invitation. The first argument is the response; the second optionally selects the event (row number or ID). With no event argument, an interactive picker over the next 90 days is shown. On a server-backed calendar this sends the reply to the organizer.

```bash
ical rsvp accepted 3       # accept the event at row 3
ical rsvp declined <id>    # decline by event ID
ical rsvp tentative        # pick interactively
```

Response words: `accepted`, `declined`, `tentative` (aliases `yes`/`no`/`maybe`). RSVPing your own (non-invitation) event is a harmless no-op.

---

## ical free

Look up free/busy availability for one or more people over a window. **Requires an Exchange or Google Workspace account** — iCloud does not support availability lookups.

```bash
ical free alice@example.com
ical free alice@example.com bob@example.com --from "monday 9am" --to "monday 6pm"
```

| Flag     | Short | Description                  | Default |
| -------- | ----- | ---------------------------- | ------- |
| `--from` | `-f`  | Start of the window          | now     |
| `--to`   | `-t`  | End of the window            | +24h    |

Prints each person's busy blocks; an address with no busy periods (or one whose server returns nothing, e.g. an iCloud address) shows "free for the whole window".

---

## ical inbox

List event invitations awaiting your response (the Calendar.app notification inbox).

```bash
ical inbox
ical inbox -o json
```

No flags beyond the global `--output`. Invitations carry no stable ID, so respond via `ical rsvp <status>` (interactive picker), or find the event with `ical list` and use its row number.

---

## ical export

Export events to JSON, CSV, or ICS format.

```bash
ical export > events.json
ical export --format ics --output-file events.ics
ical export --calendar Work --from today --to "in 6 months" --format csv
```

| Flag            | Short | Description                     | Default       |
| --------------- | ----- | ------------------------------- | ------------- |
| `--from`        | `-f`  | Start date                      | 30 days ago   |
| `--to`          | `-t`  | End date                        | 30 days ahead |
| `--calendar`    | `-c`  | Filter by calendar (repeatable) | All calendars |
| `--format`      | —     | Format: json, csv, ics          | json          |
| `--output-file` | —     | Write to file instead of stdout | stdout        |

---

## ical import

Import events from a JSON or CSV file. Format is auto-detected from file extension.

```bash
ical import events.json
ical import events.csv --calendar "Imported"
ical import backup.json --dry-run
ical import data.json --force
```

| Flag         | Short | Description                             | Default           |
| ------------ | ----- | --------------------------------------- | ----------------- |
| `--calendar` | `-c`  | Override target calendar for all events | Original calendar |
| `--dry-run`  | —     | Preview without creating events         | false             |
| `--force`    | `-f`  | Skip confirmation prompt                | false             |

---

## ical skills

Manage AI agent skills. The ical binary embeds its own agent skill files and can install them directly into the skills directory of supported AI coding agents.

### ical skills install

Install the ical agent skill for AI coding agents (Claude Code, Codex CLI, OpenClaw, GitHub Copilot, Cursor, Windsurf, Augment). Without `--agent`, shows an interactive multi-select picker followed by a confirmation prompt. The skill files are the same documentation published at https://ical.sidv.dev/docs.

```bash
ical skills install --dry-run         # Preview files without writing
ical skills install                   # Interactive — pick agents + confirm
ical skills install --agent claude    # Direct — Claude Code only
ical skills install --agent codex     # Direct — Codex CLI only
ical skills install --agent openclaw  # Direct — OpenClaw only
ical skills install --agent all       # All agents
```

| Flag        | Short | Description                                         | Default     |
| ----------- | ----- | --------------------------------------------------- | ----------- |
| `--agent`   | —     | Target agent: claude, codex, openclaw, others, or all | Interactive |
| `--dry-run` | —     | Preview what would be installed without writing        | false       |

Supported targets:
- `claude` → `~/.claude/skills/ical-cli/` (Claude Code, GitHub Copilot, Cursor, OpenCode, Augment)
- `codex` → `~/.codex/skills/ical-cli/` (Codex CLI)
- `openclaw` → `~/.openclaw/skills/ical-cli/` (OpenClaw)
- `others` → `~/.agents/skills/ical-cli/` (Copilot, Windsurf, OpenCode, Augment)

### ical skills uninstall

Remove the ical agent skill. Same `--agent` flag and interactive picker as install.

```bash
ical skills uninstall
ical skills uninstall --agent claude
```

| Flag      | Short | Description                          | Default     |
| --------- | ----- | ------------------------------------ | ----------- |
| `--agent` | —     | Target agent: claude, codex, or all  | Interactive |

### ical skills status

Show where skills are installed and whether they match the current binary version.

```bash
ical skills status
```

---

## ical version

Print version and build information. This command never prints an update or skills-staleness notice — its output is exactly one line, safe to parse.

```bash
ical version
```

Output format: `ical <version> (commit <hash>, built <date>)`

---

## ical completion

Generate shell completion scripts.

```bash
ical completion bash > /usr/local/etc/bash_completion.d/ical
ical completion zsh > "${fpath[1]}/_ical"
ical completion fish > ~/.config/fish/completions/ical.fish
```

---

## Global Flags

These flags are available on all commands:

| Flag         | Short | Description                       | Default |
| ------------ | ----- | --------------------------------- | ------- |
| `--output`   | `-o`  | Output format: table, json, plain | table   |
| `--no-color` | —     | Disable color output              | false   |

The `NO_COLOR` environment variable is also respected.

### Post-run notices

Two notices can follow a command: a new release is available, or installed skills are older than the binary. Both go to **stderr**, never stdout.

**Do not set `ICAL_NO_UPDATE_CHECK` to keep stdout parseable.** `ical <command> -o json` always emits valid JSON on stdout. Parse stdout directly.

No notice prints when any of these holds:

- `-o json` is used
- stderr is not a terminal — any pipe or redirect, including `2>&1 | jq`
- the command is `version`, `completion`, or a `skills` subcommand
- the binary is a dev build

Set `ICAL_NO_UPDATE_CHECK=1` only if your harness gives ical a pseudo-terminal on stderr and captures it. Otherwise use `2>/dev/null`.
