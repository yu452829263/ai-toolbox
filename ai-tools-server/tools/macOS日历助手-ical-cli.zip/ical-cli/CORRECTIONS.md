
## 2026-09-06 calendars update 的改名 flag 写错

- **上下文**：用户要求把日历 `ical` 改名，我按 SKILL.md `## Calendar management` 段的示例执行。
- **纠正类型**：判断偏差（照抄文档示例，未按本 skill 自己的 Gotcha 先核 `--help`）
- **现象**：`ical calendars update "ical" --name "研发"` → `Error: unknown flag: --name`。实际 flag 是 `-T` / `--title`。
- **纠正**：改用 `ical calendars update "ical" --title "研发"`，成功，9 个事件归属随之更新，数据完好。
- **根因**：SKILL.md 正文示例 `ical calendars update "Projects" --name "Side projects"` 与真实 CLI 不符。SKILL.md 的 Gotchas 已写明"需要的 flag 不在表里就别猜，跑 `--help`"，但正文示例本身给了错的 flag，读者不会意识到需要核对。**第一轮就该做对的方式**：对写操作（update/delete/create）一律先跑一次 `--help` 核对 flag，而不是信任正文示例。
- **skill patch 提议**：把 `## Calendar management` 段的 `--name` 改为 `--title`；并在该段补一句"写操作的 flag 以 `--help` 为准"。
- **状态**：已升格：SKILL.md §Calendar management 示例改为 --title（2026-09-24 周复盘，ical calendars update --help 实测）
